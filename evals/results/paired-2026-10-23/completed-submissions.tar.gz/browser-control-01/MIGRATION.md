# Bun migration

Validated with Bun 1.4.4. Install with `bun install --frozen-lockfile`, then
run `bun run typecheck` (or the preserved `bun run check` entry point) and
`bun run build`. Open `public/index.html` after building.

The build still bundles `src/main.tsx` for browsers as an IIFE at
`public/app.js`. Preact remains pinned to 10.29.0; its automatic JSX runtime
comes from the same package. TypeScript paths preserve the `@lib/` alias.
The public HTML files and application source are unchanged.

Strict checking now uses the pinned TypeScript compiler with browser libraries,
instead of `deno check`; Deno globals are intentionally unavailable. Bundling
uses Bun, so generated JavaScript and its size can differ while the visible
`Hello Ada` result and missing-element error remain unchanged. No run, serve,
or test tasks existed in the original project.

Bun has no Deno permission sandbox. These commands only check and bundle the
browser application, but tooling executes with the invoking user's permissions.
Bun's environment/configuration loading and bundler resolution can differ from
Deno's; the build does not explicitly enable environment-variable inlining.
No formatter or linter replacement is included.
