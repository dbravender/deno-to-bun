# Bun migration

Requires Bun 1.4.4 (the version used for validation). Install with
`bun install --frozen-lockfile`, then run `bun run typecheck` (or the preserved
`bun run check` entry point) and `bun run build`.

Preact remains pinned to 10.29.0. Strict checking, automatic Preact JSX, browser
DOM/ESNext declarations, and the `@lib/` source alias live in tsconfig.json.
Bun's native checker covers every TypeScript/TSX file under src, including files
not imported by the main entry point. No TypeScript runtime execution substitutes
for checking. The unused Deno namespace declarations and Deno configuration have
been removed.

The build still bundles src/main.tsx for browsers as an IIFE at public/app.js,
which public/index.html loads as a classic script. Source and HTML asset bytes
are unchanged. Bun generates different bundle text and size; byte-for-byte
bundle equivalence is not expected. No new framework or server was added.
There were no run, serve, test, formatter, or linter tasks in the original project;
formatter/linter replacement is outside this migration's scope.

Bun tool processes do not reproduce Deno's permission sandbox and run with the
invoking user's OS permissions. The application remains browser code governed by
browser security. bunfig.toml disables implicit dotenv loading to preserve the
original tools' environment handling. Dependency lifecycle scripts were not
broadly trusted or enabled.

Validation: the original Deno check/build passed. Bun typecheck, check, and build
passed both in this project and in a clean disposable copy after installation
from the frozen lockfile, with Deno absent from PATH. A temporary, unimported
source file with an invalid assignment was rejected by typecheck and then
removed. Both baseline and Bun bundles produced `Hello Ada` in a DOM-shaped VM
context and threw `missing app element` when that element was absent. SHA-256
hashes of public/index.html and public/legal.html match their baseline values.
There were no existing tests or skips to port. A real browser session, hosted CI,
and deployment were not exercised; the VM smoke check does not validate all
browser integration behavior.
