# Bun migration

Use Bun 1.4.4 (the supplied and validated version). Install development dependencies
with `bun install --frozen-lockfile`.

## Entry points

- `bun run run [name] [count]` runs the CLI.
- `bash scripts/run.sh [name] [count]` preserves the shell launcher, including
  invocation from another working directory.
- `bun run typecheck` performs strict static checking with Bun's native `bun check`
  and the project tsconfig. `bun run check` and `make check` retain the existing
  check entry points. CI installs the locked dependencies and runs this check.

The original project had no test, serve, or build task. No such task was added.
The import alias `@lib/` now lives in `tsconfig.json`. The source shebang invokes
Bun with automatic environment-file loading disabled. Deno configuration and
execution have been removed.

## Behavior and security

Arguments, defaults, trimming, JSON output, positive-integer validation, error
text, and exit status 2 for invalid counts are preserved. Environment reads use
`process.env`; absent values still produce JSON null.

Bun normally loads environment files automatically. `bunfig.toml` sets
`env = false` so `bun run run` and direct project invocations read inherited
variables only, matching the original behavior. The source shebang and shell
launcher additionally use `--no-env-file`. Explicit `--env-file` remains an
opt-in Bun feature. See the [Bun environment documentation](https://bun.com/docs/runtime/environment-variables).

Bun does not enforce Deno's runtime permission boundary. The old launcher granted
all environment access but restricted filesystem, network, subprocess, and other
capabilities by default. The Bun process has the operating-system permissions of
its user. Run it in an external sandbox/container if that isolation is required.
The application itself still only reads arguments and two environment variables.

There were no external application dependencies to preserve. The only added
direct development dependency is exact-pinned `@types/node` 26.6.5 for the
Node-compatible `process` API; `bun.lock` pins its transitive dependency too.
Bun 1.4.4 supplies the checker, so no TypeScript compiler package is needed.
Formatting and lint replacement were outside this migration's scope.

## Validation

- Captured the original Deno default and named-argument output and strict check.
- `bun install --frozen-lockfile` succeeded using the local installation cache.
- `bun run typecheck` and `make check` passed.
- 35 automated assertions covered default/custom/empty names, invalid counts,
  inherited versus dotenv environment variables, the package/direct/shell entry
  points, shell invocation from outside the project, and rejection of an injected
  type error. The injected error and temporary environment file were removed.
- Verified no Deno execution/configuration references remain in project code.

The hosted GitHub Actions workflow was updated but was not executed remotely.
