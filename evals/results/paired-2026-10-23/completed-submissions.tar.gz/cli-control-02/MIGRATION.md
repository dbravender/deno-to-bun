# Bun migration

Use Bun 1.4.4. Install dependencies with `bun install --frozen-lockfile`.

- `bun run run [name] [count]` replaces the previous run task.
- `bash scripts/run.sh [name] [count]` remains the shell entry point.
- `bun run check`, `make check`, and `bun run typecheck` run TypeScript with strict checking and no output emission.
- `bun src/main.ts [name] [count]` runs the CLI directly. The shebang also uses Bun.

The JSON schema, default arguments, name trimming, number conversion, environment reads, and invalid-count exit status (2) are unchanged. The `@lib/` alias moved from the import map to TypeScript paths, which Bun resolves at runtime.

There were no runtime dependencies, tests, serve tasks, or build tasks in the original project. TypeScript 6.0.3 matches the supplied baseline checker; Bun type definitions are pinned to 1.4.4. `bun.lock` fixes their transitive dependencies. CI installs the pinned Bun runtime and uses the frozen lockfile before checking.

## Environment and security

Automatic `.env` loading is disabled in `bunfig.toml` and explicitly in the scripted runtime invocations, preserving inherited-environment behavior. Bun documents this configuration at https://bun.com/docs/runtime/environment-variables.

The original runtime permitted environment access with `--allow-env` but denied filesystem, network, and subprocess access by default. Bun does not enforce that permission boundary: the program and any future dependency run with the operating-system permissions of the invoking account. Use an external sandbox when that isolation is required. The CLI itself adds no filesystem, network, or subprocess operations.

Formatter and linter replacement are outside this migration's scope.
