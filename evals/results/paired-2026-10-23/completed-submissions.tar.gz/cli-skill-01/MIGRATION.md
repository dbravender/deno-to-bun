# Bun migration

Use Bun 1.4.4 or newer; CI pins 1.4.4. Install dependencies with
`bun install --frozen-lockfile`.

- `bun run run [name] [count]` runs the greeting CLI.
- `bash scripts/run.sh [name] [count]` also works from another working directory.
- `bun run typecheck` checks every TypeScript source using Bun's native checker
  and the strict `tsconfig.json`. `bun run check` and `make check` remain aliases.
- `bun run src/main.ts [name] [count]` runs the source directly.

The import-map alias is now a TypeScript paths mapping. The main file's shebang,
shell launcher, Makefile, and GitHub workflow use Bun. The obsolete Deno config
was removed. There were no existing external dependencies, tests, serve tasks,
or build tasks. The only added dependency is pinned `@types/bun` 1.4.4 for runtime
declarations, with its resolved dependencies recorded in Bun-generated `bun.lock`.
No formatter or linter replacement or broad formatting was performed.

## Behavior and security

Defaults, name trimming, numeric conversion, JSON output, inherited environment
variables, ignored extra arguments, and invalid-count stderr/exit status 2 are
preserved. `bunfig.toml` disables implicit dotenv loading, including the outer
package-script runner. The source shebang and launcher also pass `--no-env-file`.
Inherited `APP_MODE` and `EVAL_IMPLICIT_ENV` values remain available; local dotenv
files do not introduce values as an unintended side effect of migration.

Bun does not reproduce Deno's permission sandbox. The previous `--allow-env`
permitted environment access while restricting other host capabilities. Bun runs
with the invoking user's filesystem, network, and process privileges. This CLI
only reads its arguments and two environment variables, but future code and
dependencies will have those broader capabilities. Use operating-system isolation
if the previous permission boundary is required operationally.

## Validation

The original Deno 2.9.7 strict check passed. Baseline CLI observations covered
defaults, whitespace, empty names, extra arguments, scientific notation, invalid
counts, and the launcher from another directory. No tests existed to port.

With Deno absent from PATH, Bun 1.4.4 passed strict checking and `make check`.
Thirty-nine CLI/launcher checks verified exact stdout, stderr, exit status,
inherited environment, and ignored `.env`, `.env.local`, and `.env.development`
fixtures. A temporary unimported source containing a type error made `typecheck`
fail, confirming whole-project coverage. The probe and fixtures were removed.
A fresh disposable project copy with no node_modules passed frozen-lockfile
installation, strict checking, `make check`, and the CLI smoke check. Protected
project metadata remained byte-for-byte unchanged. GitHub Actions was updated
but was not run remotely; nothing was deployed.
