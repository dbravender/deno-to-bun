# Bun migration

Requires Bun 1.4.4 (also pinned in CI and packageManager). Install with
`bun install --frozen-lockfile`.

- Run: `bun run run [name] [count]`, `bun src/main.ts [name] [count]`, or
  `bash scripts/run.sh [name] [count]` (the shell launcher also works from other
  working directories). The existing source and shell file modes are retained.
- Check: `bun run typecheck`, `bun run check`, or `make check`. Native Bun checking
  uses strict tsconfig settings and includes every TypeScript file under src,
  including files not imported by the CLI. The @lib alias is shared by execution
  and checking through tsconfig paths.
- The original project had no tests, serve task, build task, assets, or runtime
  dependencies. No replacement formatter or linter is introduced.

Deno configuration and execution have been removed. Arguments, name trimming,
JSON fields, environment values, and invalid-count stderr/exit status 2 are
preserved. Bun automatic dotenv loading is disabled in bunfig.toml and explicitly
in the CLI launch commands, preserving the original explicit environment behavior.
The new development-only dependency @types/bun is pinned to 1.4.4; bun.lock records
its resolved dependency graph. No existing dependency versions were replaced.

Security difference: the old Deno command allowed environment access while
restricting filesystem, network, and subprocess access by default. Bun does not
provide that permission sandbox; the CLI has normal process permissions. Run it
under OS/container isolation when handling untrusted code. The migrated CLI
itself only reads arguments/environment and writes console output. Dependency
lifecycle scripts have not been broadly enabled.

Validation: baseline Deno strict checking passed. After migration, strict Bun
checking and make check passed. Eight cases (defaults, trimmed/empty names,
valid/invalid counts, and extra arguments) were compared against the Deno baseline
through direct Bun, package script, and shell launcher: 24 matching outputs and
exit statuses. A harmless .env fixture stayed unloaded through all three paths.
An unimported source type-error probe was rejected, then removed. Clean frozen
installation and checks were verified with Deno absent from PATH. Hosted GitHub
Actions was updated but not executed remotely. Formatter/linter replacement and
broad reformatting remain outside scope.
