# Bun migration

Use Bun 1.4.4. Install development dependencies reproducibly with
`bun install --frozen-lockfile`.

## Commands

- `bun run run -- <operation> <path> [text]` runs the CLI. Supported operations
  remain `new`, `replace`, `read`, `missing`, `list`, and `child`.
- `bun run check` preserves the previous checking entry point.
- `bun run typecheck` runs TypeScript 6.0.3 with `strict: true` and no emission,
  covering application sources and regression tests. Bun execution alone does
  not typecheck TypeScript.
- `bun test` runs the added regression tests.

No serve or build tasks existed. No production dependencies existed. The new
exact development dependencies are TypeScript 6.0.3 and Bun types 1.4.4; bun.lock
also pins their transitive dependencies. Deno configuration and execution have
been removed.

## Preserved behavior

The CLI uses Node filesystem APIs provided by Bun. Exclusive creation uses `wx`
so existing files cannot be overwritten; replace creates or truncates a file.
Text reads return JSON-encoded UTF-8 text. Missing-file detection catches only
`ENOENT`; other read errors still fail. Listings sort regular file names and
exclude directories and symbolic links. The child runs with the same Bun
executable as its parent, using a filesystem path derived from the module URL.
Both output streams are drained concurrently and fully, and its exit code 7 is
reported in the parent's JSON output without failing the parent.

## Intentional runtime and security differences

Bun does not implement Deno's permission sandbox. The previous main command
explicitly allowed read/write/process execution, while other capabilities such
as environment and network access remained restricted. Bun and spawned Bun
children inherit the host user's ordinary permissions, including filesystem,
environment, and network access. The previous child had no Deno permission
flags. Use operating-system isolation when running untrusted code or inputs;
this migration does not provide a replacement capability sandbox.

Filesystem failures now use Node error codes rather than Deno error classes.
Uncaught-error messages, stack traces, and package task banners differ by
runtime; failure remains nonzero. The public successful output and file side
effects are preserved.

## Validation

On the supplied Bun 1.4.4 executable: `bun run typecheck`, `bun run check`,
`bun test` (6 passing tests, 18 assertions), and `bun install --frozen-lockfile`
passed. A disposable comparison against the supplied Deno baseline matched all
10 observations for stdout, exit status, and preserved file contents, including
both complete 120,001-byte child streams. Tests cover exclusive creation,
UTF-8/JSON text, default empty text, replacement truncation and creation,
missing-file handling and other errors, sorted file-only listings, child output,
and unknown operations.

Validation was on macOS; other operating systems and adversarial concurrent
filesystem changes were not separately tested. Formatting/lint replacement is
outside this migration's scope.
