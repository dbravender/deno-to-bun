import { afterEach, beforeEach, expect, test } from "bun:test";
import { mkdtemp, mkdir, readFile, rm, symlink, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { fileURLToPath } from "node:url";

const main = fileURLToPath(new URL("../src/main.ts", import.meta.url));
let directory: string;
beforeEach(async () => { directory = await mkdtemp(join(tmpdir(), "file-operations-")); });
afterEach(async () => { await rm(directory, { recursive: true, force: true }); });

function run(...args: string[]) {
  const result = Bun.spawnSync([process.execPath, main, ...args]);
  return {
    code: result.exitCode,
    stdout: result.stdout.toString(),
    stderr: result.stderr.toString(),
  };
}

test("exclusive creation preserves existing files and defaults to empty text", async () => {
  const path = join(directory, "note.txt");
  expect(run("new", path, "한글\nhello").code).toBe(0);
  expect(await readFile(path, "utf8")).toBe("한글\nhello");
  expect(run("new", path, "bad").code).not.toBe(0);
  expect(await readFile(path, "utf8")).toBe("한글\nhello");
  const empty = join(directory, "empty");
  expect(run("new", empty).code).toBe(0);
  expect(await readFile(empty, "utf8")).toBe("");
});

test("replace creates and truncates files; read returns JSON text", async () => {
  const path = join(directory, "note.txt");
  expect(run("replace", path, "long text").code).toBe(0);
  expect(run("replace", path, "짧음\n").code).toBe(0);
  expect(run("read", path)).toEqual({ code: 0, stdout: '"짧음\\n"\n', stderr: "" });
});

test("missing handles only absent files and propagates other errors", async () => {
  const path = join(directory, "note.txt");
  expect(run("missing", path).stdout).toBe('{"missing":true}\n');
  await writeFile(path, "present");
  expect(run("missing", path).stdout).toBe('{"missing":false}\n');
  expect(run("missing", directory).code).not.toBe(0);
  expect(run("read", join(directory, "absent")).code).not.toBe(0);
});

test("list sorts files and excludes directories and symlinks", async () => {
  await writeFile(join(directory, "z"), "");
  await writeFile(join(directory, "a"), "");
  await mkdir(join(directory, "folder"));
  await symlink("a", join(directory, "link"));
  expect(run("list", directory)).toEqual({ code: 0, stdout: '["a","z"]\n', stderr: "" });
});

test("child captures both large streams fully and preserves exit status", () => {
  const result = run("child");
  expect(result.code).toBe(0);
  expect(result.stderr).toBe("");
  expect(JSON.parse(result.stdout)).toEqual({ code: 7, stdout: "out".repeat(40000) + "\n", stderr: "err".repeat(40000) + "\n" });
});

test("unknown operations fail", () => {
  expect(run("unknown").code).not.toBe(0);
});
