# Bun migration

Requires Bun 1.4.4. Install dependencies with `bun install --frozen-lockfile`.
Use `bun run run -- <operation> <path> [text]` for the CLI,
`bun run typecheck` for strict TypeScript checking, and `bun run check` for
the previous check entry point. Run regression checks with `bun test`.
The original project had no serve, test, or build task; no build is required.

File operations now use Node-compatible filesystem APIs. Exclusive creation
uses `wx`, replacement still truncates or creates, and missing-file detection
handles only `ENOENT`. Directory listings still exclude directories and symlinks
and sort filenames. UTF-8 decoding preserves the BOM and replaces malformed
UTF-8, matching the original runtime. Child execution uses the current
Bun executable with an absolute source path, collecting stdout and stderr
concurrently while retaining the child's exit status.

Bun does not implement Deno's permission sandbox. The former run task granted
read, write, and subprocess access; Bun additionally has the process user's
normal environment and network access. Use an OS sandbox if isolation is
required. Runtime exception names, stack traces, and diagnostic formatting
can differ; failed operations still fail without swallowing unrelated errors.

There were no application dependencies to migrate. TypeScript 7.0.2 and
@types/bun 1.4.4 are exact development dependencies, locked in bun.lock.
Deno configuration and execution have been removed. Formatting/linting
replacement and broad reformatting are intentionally out of scope.
