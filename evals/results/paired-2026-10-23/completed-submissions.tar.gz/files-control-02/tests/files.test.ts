import { expect, test } from "bun:test";
import { mkdir, mkdtemp, readFile, rm, symlink, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { fileURLToPath } from "node:url";

const main = fileURLToPath(new URL("../src/main.ts", import.meta.url));

async function run(...args: string[]) {
  const child = Bun.spawn([process.execPath, main, ...args], {
    stdout: "pipe",
    stderr: "pipe",
  });
  const [code, stdout, stderr] = await Promise.all([
    child.exited,
    new Response(child.stdout).text(),
    new Response(child.stderr).text(),
  ]);
  return { code, stdout, stderr };
}

test("file operations retain exclusive creation, decoding, and file-only listing", async () => {
  const dir = await mkdtemp(join(tmpdir(), "bun-files-"));
  try {
    const path = join(dir, "a.txt");
    expect((await run("new", path, "hello 한글")).code).toBe(0);
    expect((await run("new", path, "overwrite")).code).not.toBe(0);
    expect(await readFile(path, "utf8")).toBe("hello 한글");
    expect((await run("replace", path, "x")).code).toBe(0);
    expect((await run("read", path)).stdout).toBe('"x"\n');
    expect((await run("replace", join(dir, "b.txt"), "created")).code).toBe(0);
    expect((await run("missing", path)).stdout).toBe('{"missing":false}\n');
    expect((await run("missing", join(dir, "absent"))).stdout).toBe('{"missing":true}\n');
    expect((await run("missing", dir)).code).not.toBe(0);
    await mkdir(join(dir, "nested"));
    await symlink(path, join(dir, "link"));
    expect((await run("list", dir)).stdout).toBe('["a.txt","b.txt"]\n');
    await writeFile(path, new Uint8Array([0xef, 0xbb, 0xbf, 0x61, 0xff]));
    expect((await run("read", path)).stdout).toBe('"\uFEFFa�"\n');
    expect((await run("unknown")).code).not.toBe(0);
  } finally {
    await rm(dir, { recursive: true, force: true });
  }
});

test("child output drains both streams and preserves nonzero exit status", async () => {
  const result = await run("child");
  expect(result.code).toBe(0);
  expect(result.stderr).toBe("");
  expect(JSON.parse(result.stdout)).toEqual({
    code: 7,
    stdout: "out".repeat(40000) + "\n",
    stderr: "err".repeat(40000) + "\n",
  });
});
