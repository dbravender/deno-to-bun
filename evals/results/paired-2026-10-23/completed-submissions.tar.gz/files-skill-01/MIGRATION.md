# Bun migration

Use Bun 1.4.4 or newer. This migration was verified with Bun 1.4.4 on macOS
ARM64; the original baseline used Deno 2.9.7.

```sh
bun install --frozen-lockfile
bun run typecheck
bun run check
bun run test
bun run run new /tmp/example.txt 'héllo 🌎'
bun run run read /tmp/example.txt
```

The `run` and `check` entry points replace the original Deno tasks. `typecheck`
uses Bun's native checker with strict TypeScript settings and covers all source
files, including `src/child.ts`, and the regression tests. `check` invokes the
same checker. No serve or build tasks existed. Formatting and linting were not
added or changed.

There were no original external dependencies to preserve. The only new direct
dependency is the development declaration package `@types/bun`, pinned to 1.4.4;
its transitive declarations are recorded in the generated `bun.lock`. No runtime
packages or trusted installation scripts are required. `deno.json` was removed.

## Preserved behavior

- `new` uses exclusive creation (`wx`) and never overwrites an existing file.
- `replace` creates absent files and truncates existing content. Omitted text
  remains an empty string. Reads and writes use UTF-8.
- `missing` recognizes nonexistent paths by `ENOENT`, and propagates other
  filesystem errors. Runtime-specific error names, messages, and stack traces
  differ; failures still exit unsuccessfully.
- `list` returns sorted regular filenames and excludes directories and symlinks.
- `child` executes the adjacent TypeScript child with the current Bun executable,
  converts its file URL to a filesystem path, ignores stdin, and drains both
  output pipes concurrently. It returns JSON containing exit code 7 and the
  complete stdout/stderr strings. The parent exits successfully as before.
- `bunfig.toml` disables automatic dotenv loading, matching the original runtime.

## Security and operational differences

Bun has no equivalent to Deno's permission sandbox. The original launcher granted
filesystem reads, writes, and subprocess execution, but withheld other permissions
such as network and environment access. Bun runs with the user's normal OS
privileges, including those additional capabilities. Use an OS sandbox or
container if that boundary is required for untrusted execution. No permissions,
services, or global tools were changed by this migration.

## Verification

The original strict Deno check and 12 filesystem/process baseline checks passed.
There were no original tests or skips. Six Bun regression tests (18 assertions,
zero failures/skips) now cover exclusive creation, Unicode reads, truncation,
creation, omitted text, missing-file classification, directory errors, sorted
listing, symlinks, unknown operations, and the large subprocess streams
(120,001 bytes per stream) and exit status.

A fresh disposable copy installed successfully using `bun install
--frozen-lockfile --offline`, with no copied `node_modules`, using the downloaded
package cache. Both strict check commands and the tests passed with Deno absent
from PATH. Additional probes verified package-script argument forwarding with
spaces and Unicode, that dotenv stays disabled through the outer script runner
and inner runtime, and that an intentional type error in `src/child.ts` causes
`typecheck` to fail. The probes and intentional error were confined to the
disposable copy and removed afterward.

Validation was local on macOS; other operating systems and hosted environments
were not tested. There is no deployment or hosted CI configuration in this
project.
