import { afterEach, expect, test } from "bun:test";
import { mkdtemp, mkdir, readFile, rm, symlink, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { fileURLToPath } from "node:url";

const main = fileURLToPath(new URL("../src/main.ts", import.meta.url));
const directories: string[] = [];
async function fixture() {
  const directory = await mkdtemp(join(tmpdir(), "files-cli-"));
  directories.push(directory);
  return directory;
}
afterEach(async () => {
  await Promise.all(directories.splice(0).map((directory) => rm(directory, { recursive: true, force: true })));
});
async function run(...args: string[]) {
  const child = Bun.spawn([process.execPath, main, ...args], {
    stdin: "ignore", stdout: "pipe", stderr: "pipe",
  });
  const [code, stdout, stderr] = await Promise.all([
    child.exited, new Response(child.stdout).text(), new Response(child.stderr).text(),
  ]);
  return { code, stdout, stderr };
}

test("exclusive creation preserves existing content and UTF-8 reads", async () => {
  const path = join(await fixture(), "unicode.txt");
  expect((await run("new", path, "héllo 🌎")).code).toBe(0);
  expect((await run("new", path, "must not overwrite")).code).not.toBe(0);
  expect(await readFile(path, "utf8")).toBe("héllo 🌎");
  expect(await run("read", path)).toEqual({ code: 0, stdout: '"héllo 🌎"\n', stderr: "" });
});

test("replace truncates and creates absent files; omitted text is empty", async () => {
  const path = join(await fixture(), "replace.txt");
  expect((await run("replace", path, "a longer string")).code).toBe(0);
  expect((await run("replace", path, "短")).code).toBe(0);
  expect(await readFile(path, "utf8")).toBe("短");
  expect((await run("replace", path)).code).toBe(0);
  expect(await readFile(path, "utf8")).toBe("");
});

test("missing recognizes only nonexistent paths and preserves other errors", async () => {
  const directory = await fixture();
  const path = join(directory, "present");
  await writeFile(path, "");
  expect(JSON.parse((await run("missing", path)).stdout)).toEqual({ missing: false });
  expect(JSON.parse((await run("missing", join(directory, "absent"))).stdout)).toEqual({ missing: true });
  expect((await run("missing", directory)).code).not.toBe(0);
  expect((await run("read", join(directory, "absent"))).code).not.toBe(0);
});

test("listing sorts regular files and excludes directories and symlinks", async () => {
  const directory = await fixture();
  await writeFile(join(directory, "z"), "");
  await writeFile(join(directory, "a"), "");
  await mkdir(join(directory, "directory"));
  await symlink(join(directory, "a"), join(directory, "link"));
  expect(JSON.parse((await run("list", directory)).stdout)).toEqual(["a", "z"]);
});

test("child captures both complete large streams and nonzero exit status", async () => {
  const result = await run("child");
  expect(result.code).toBe(0);
  expect(result.stderr).toBe("");
  expect(JSON.parse(result.stdout)).toEqual({
    code: 7, stdout: "out".repeat(40000) + "\n", stderr: "err".repeat(40000) + "\n",
  });
}, 10000);

test("unknown operation fails", async () => {
  expect((await run("unknown")).code).not.toBe(0);
});
