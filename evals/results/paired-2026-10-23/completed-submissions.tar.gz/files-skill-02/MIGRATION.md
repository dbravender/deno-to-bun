# Bun migration

Requires Bun 1.4.4 or newer. Validated with the supplied Bun 1.4.4 executable;
no global runtime installation was changed. There were no original package
 dependencies or test suites. Added exact `@types/bun` 1.4.4 for checking;
`bun.lock` pins it and its transitive declaration dependencies.

## Commands

- `bun install --frozen-lockfile`
- `bun run run <operation> [path] [text]`
- `bun run typecheck` (strict checking of both entry points and regression tests)
- `bun run check` (retained check task alias)
- `bun run test` (five added regression tests, no skips)

Operations remain `new`, `replace`, `read`, `missing`, `list`, and `child`.
No serve or build task existed. Deno configuration and execution were removed.
Formatting and linting remain outside this migration's scope.

## Behavior

Node filesystem promises preserve exclusive creation (`wx`), default replacement
and truncation, and awaited file closure. TextDecoder preserves the original
UTF-8 BOM removal and malformed-byte replacement behavior. Directory listings
sort regular filenames and exclude directories and symbolic links. Only ENOENT
becomes `{ "missing": true }`; other filesystem errors still fail the command.

The child uses the current Bun executable and a filesystem path derived from its
module URL. Both pipes drain concurrently, preserving all 120,001 bytes per pipe
and the child exit code 7 in the parent JSON response. The parent still exits
successfully after reporting this child result. Runtime stack traces and native
filesystem error wording differ from Deno, while command success/failure and JSON
outputs are preserved.

## Security and environment

Bun has the host process's filesystem, environment, subprocess, and network
access. It does not reproduce Deno's permission sandbox. The previous launcher
allowed all reads, writes, and subprocess execution but did not grant network or
environment access; those runtime restrictions are now absent. Use an external
OS/container policy if those restrictions are required. No additional application
network requests or environment reads were introduced.

`bunfig.toml` disables implicit dotenv loading, matching the original explicit
environment behavior. Run commands from the project directory so this config is
loaded. No dependency lifecycle script trust was enabled.

## Validation

Before editing, Deno strict checking and filesystem/CLI/subprocess behavior checks
passed. After migration, strict checking passes and five regression tests pass
with zero failures/skips. Tests cover exclusive creation, truncation, Unicode and
BOM/malformed-byte decoding, missing/error classification, sorted directory
filtering, and large dual-stream child output.

A fresh temporary copy installed successfully with the frozen lockfile and no
project node_modules, then passed typecheck, check, and test with Deno absent from
PATH. Additional checks exercised package-script argument forwarding, unknown
operation failure, preservation on exclusive-create failure, full child output,
and dotenv suppression through the script runner. An injected type error in a
temporary copy of child.ts correctly failed typecheck, confirming whole-project
coverage. No deployment or hosted environment was tested.
