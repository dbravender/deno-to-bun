import { afterEach, expect, test } from "bun:test";
import { mkdtemp, mkdir, readFile, rm, symlink, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { fileURLToPath } from "node:url";

const fixtures: string[] = [];
async function fixture() {
  const path = await mkdtemp(join(tmpdir(), "files-cli-"));
  fixtures.push(path);
  return path;
}
afterEach(async () => {
  await Promise.all(fixtures.splice(0).map((path) => rm(path, { recursive: true, force: true })));
});
async function run(...args: string[]) {
  const child = Bun.spawn([process.execPath, fileURLToPath(new URL("../src/main.ts", import.meta.url)), ...args], {
    stdout: "pipe",
    stderr: "pipe",
  });
  const [code, stdout, stderr] = await Promise.all([
    child.exited, new Response(child.stdout).text(), new Response(child.stderr).text(),
  ]);
  return { code, stdout, stderr };
}

test("exclusive creation preserves existing contents and replacement truncates", async () => {
  const path = join(await fixture(), "value.txt");
  expect((await run("new", path, "héllo 世界")).code).toBe(0);
  expect((await run("new", path, "oops")).code).not.toBe(0);
  expect(await readFile(path, "utf8")).toBe("héllo 世界");
  expect((await run("replace", path, "x")).code).toBe(0);
  expect(JSON.parse((await run("read", path)).stdout)).toBe("x");
  expect((await run("replace", path)).code).toBe(0);
  expect(await readFile(path, "utf8")).toBe("");
});

test("text decoding removes a UTF-8 BOM and replaces malformed bytes", async () => {
  const path = join(await fixture(), "value.txt");
  await writeFile(path, new Uint8Array([0xef, 0xbb, 0xbf, 0x61, 0xff]));
  expect(JSON.parse((await run("read", path)).stdout)).toBe("a\ufffd");
});

test("only missing files produce the missing result", async () => {
  const dir = await fixture();
  const path = join(dir, "value.txt");
  expect(JSON.parse((await run("missing", path)).stdout)).toEqual({ missing: true });
  await writeFile(path, "value");
  expect(JSON.parse((await run("missing", path)).stdout)).toEqual({ missing: false });
  expect((await run("missing", dir)).code).not.toBe(0);
});

test("listing sorts regular files and excludes directories and symlinks", async () => {
  const dir = await fixture();
  await writeFile(join(dir, "z.txt"), "z");
  await writeFile(join(dir, "a.txt"), "a");
  await mkdir(join(dir, "subdirectory"));
  await symlink(join(dir, "a.txt"), join(dir, "link.txt"));
  expect(JSON.parse((await run("list", dir)).stdout)).toEqual(["a.txt", "z.txt"]);
});

test("child captures both large output streams and its nonzero exit code", async () => {
  const result = await run("child");
  expect(result.code).toBe(0);
  expect(JSON.parse(result.stdout)).toEqual({
    code: 7,
    stdout: "out".repeat(40000) + "\n",
    stderr: "err".repeat(40000) + "\n",
  });
}, 10000);
