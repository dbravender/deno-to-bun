# Bun migration

Requires Bun 1.4.4 (the supplied executable was used for validation).

```sh
bun install --frozen-lockfile
bun run typecheck
bun run check
bun run serve /absolute/path/to/static/root
```

`serve` retains its root directory argument and listens only on `127.0.0.1`, on
an automatically assigned port. It prints one JSON object containing `port` on
stdout after binding. `check` remains available as an alias for the real strict
TypeScript `typecheck` script. The original project had no run, test, or build
tasks or external dependencies. TypeScript 7.0.2 and Bun types 1.4.4 are pinned
new development dependencies; bun.lock pins their transitive dependencies.

The health, POST echo, static-file, and fallback routes retain their status
codes and bodies. Real-path resolution and the root-plus-separator containment
check retain the existing treatment of symlinks and traversal. Missing files,
directories, and malformed percent escapes return 404. An existing file resolved
outside the root returns 403. The original resolve-then-read filesystem race
remains; serve a trusted, stable directory.

Bun infers different default content types than Deno. JSON and error responses
therefore specify the original content types explicitly. Static files use a
single-chunk byte stream, preserving binary
bytes and the original absence of a content-type header.

## Intentional runtime and security differences

Deno's `--allow-read --allow-net=127.0.0.1` permissions have no equivalent in
this Bun launch command. Bun runs with the operating system user's filesystem,
network, environment, and process privileges. The explicit loopback bind and
static-root containment remain, but they are not a runtime permission sandbox.
Use operating-system isolation if the former Deno permission restrictions are
required. No Deno executable or configuration is used by the migrated project.

HTTP transport behavior (such as connection management, default request-size
limits, timeout handling, transfer framing, and generated Date headers) is supplied by Bun rather
than Deno. This migration retains Bun's transport defaults. Bun's default maximum
request body is 128 MiB; larger echo requests may be rejected before the handler.
Static responses can use chunked transfer encoding rather than Content-Length.
Bun development error pages are disabled to avoid exposing source details on
unhandled errors.

## Validation

Strict `bun run typecheck` and the retained `bun run check` pass. An independent
local harness compared the original Deno server with `bun run serve` for 19
requests, checking status, raw body, and content type. Cases
covered health, UTF-8 and empty POST echo, wrong methods, fallback, text and
binary and empty files, static POST, health HEAD, percent-encoded names, missing
paths, malformed escapes and NUL,
directories, internal and external symlinks, and encoded traversal into a
sibling directory. Startup JSON and root-argument forwarding were also checked.
No pre-existing tests or skipped assertions existed to port.
