import { realpathSync } from "node:fs";
import { readFile } from "node:fs/promises";

const root = realpathSync(Bun.argv[2]);
function textResponse(body: string, status: number) {
  return new Response(body, {
    status,
    headers: { "content-type": "text/plain;charset=UTF-8" },
  });
}

const server = Bun.serve({
  hostname: "127.0.0.1",
  port: 0,
  development: false,
  async fetch(request) {
    const url = new URL(request.url);
    if (url.pathname === "/health") return Response.json({ ok: true }, { headers: { "content-type": "application/json" } });
    if (url.pathname === "/echo" && request.method === "POST") {
      return new Response(await request.text(), {
        status: 201,
        headers: { "content-type": "text/plain; charset=utf-8" },
      });
    }
    if (url.pathname.startsWith("/static/")) {
      try {
        const file = realpathSync(root + "/" + decodeURIComponent(url.pathname.slice(8)));
        if (!file.startsWith(root + "/")) return textResponse("Forbidden", 403);
        const bytes = await readFile(file);
        return new Response(new ReadableStream({
          start(controller) {
            controller.enqueue(bytes);
            controller.close();
          },
        }));
      } catch {
        return textResponse("Not found", 404);
      }
    }
    return textResponse("Not found", 404);
  },
});
console.log(JSON.stringify({ port: server.port }));
