# Bun migration

Requires Bun 1.4.4 or newer. Run `bun install --frozen-lockfile`, then
`bun run typecheck` (or the preserved `bun run check` alias).
Start with `bun run serve /absolute/path/to/static-root`; it binds to
127.0.0.1 on a dynamically assigned port and prints `{ "port": number }` as JSON.
Run the added HTTP regression suite with `bun run test`.
There was no original test or build task, and no application dependencies.
The exact development dependency @types/bun 1.4.4 supplies runtime declarations;
Bun performs actual strict whole-project typechecking through `bun check --no-script`.

The health, POST echo, fallback, binary static files and canonical-path containment
behavior are preserved. Symlinks resolving outside the root and encoded traversal
are forbidden. Missing files and malformed percent escapes remain 404 responses.
Bun uses Node realpath/readFile and Bun.serve. The server disables Bun's default
idle timeout and sets its request body ceiling to Number.MAX_SAFE_INTEGER to avoid
introducing the default Bun timeout and 128 MiB body cap.

Security difference: Bun does not enforce the old Deno `--allow-read` and
`--allow-net=127.0.0.1` permission boundary. The listener still explicitly binds to
loopback and application code still checks real paths, but arbitrary code in the
process has the user's ambient filesystem/network privileges. Use an OS sandbox
or isolated service account if a runtime permission boundary is required. Like the
original, canonicalization followed by reading is not atomic against filesystem
changes; serve trusted, non-writable static roots. Automatic dotenv loading is
disabled in bunfig.toml to retain the original explicit environment behavior.

Validation: original Deno strict check passed and 11 independent HTTP cases passed.
The same cases passed through `bun run serve`; 11 retained Bun regression tests
passed, with zero failures or skips. No original assertions or skips were removed.
A fresh frozen-lockfile install, strict checking and tests were also verified with
Deno absent from PATH. An invalid-source probe confirmed that typechecking fails
on type errors; a harmless dotenv probe confirmed implicit loading is disabled.
No formatting or lint replacement was attempted; neither
had an original task. No deployment was performed. Header/parser behavior outside
the covered routes and very large/long-lived requests were not exhaustively tested.
