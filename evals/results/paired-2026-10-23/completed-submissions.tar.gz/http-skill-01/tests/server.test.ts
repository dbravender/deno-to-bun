import { afterAll, beforeAll, expect, test } from "bun:test";
import { mkdtemp, mkdir, rm, symlink, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";

let directory: string;
let server: ReturnType<typeof Bun.spawn>;
let origin: string;
const binary = Uint8Array.from({ length: 256 }, (_, i) => i);

beforeAll(async () => {
  directory = await mkdtemp(join(tmpdir(), "bun-http-"));
  const root = join(directory, "public");
  await mkdir(root);
  await writeFile(join(root, "hello.txt"), "hello ☃");
  await writeFile(join(root, "bytes.bin"), binary);
  await writeFile(join(directory, "outside.txt"), "private");
  await symlink(join(directory, "outside.txt"), join(root, "escape"));
  server = Bun.spawn([process.execPath, "src/server.ts", root], {
    cwd: join(import.meta.dir, ".."),
    stdout: "pipe",
    stderr: "inherit",
  });
  if (typeof server.stdout === "number" || !server.stdout) throw new Error("Missing server stdout");
  const reader = server.stdout.getReader();
  let output = "";
  while (!output.includes("\n")) {
    const { value, done } = await reader.read();
    if (done) throw new Error("Server exited before reporting its port");
    output += new TextDecoder().decode(value);
  }
  reader.releaseLock();
  const { port } = JSON.parse(output.split("\n")[0]);
  expect(port).toBeGreaterThan(0);
  origin = `http://127.0.0.1:${port}`;
});

afterAll(async () => {
  server?.kill();
  if (server) await server.exited;
  if (directory) await rm(directory, { recursive: true, force: true });
});

const cases: [string, string | undefined, number, string | Uint8Array<ArrayBuffer>][] = [
  ["/health", undefined, 200, '{"ok":true}'],
  ["/echo", "echo ☃", 201, "echo ☃"],
  ["/echo", undefined, 404, "Not found"],
  ["/unknown", undefined, 404, "Not found"],
  ["/static/hello.txt", undefined, 200, "hello ☃"],
  ["/static/bytes.bin", undefined, 200, binary],
  ["/static/missing", undefined, 404, "Not found"],
  ["/static/%ZZ", undefined, 404, "Not found"],
  ["/static/%2e%2e%2foutside.txt", undefined, 403, "Forbidden"],
  ["/static/escape", undefined, 403, "Forbidden"],
  ["/static/", undefined, 403, "Forbidden"],
];

for (const [path, body, status, expected] of cases) {
  test(`${body === undefined ? "GET" : "POST"} ${path}`, async () => {
    const response = await fetch(origin + path, { method: body === undefined ? "GET" : "POST", body });
    expect(response.status).toBe(status);
    if (typeof expected === "string") {
      expect(await response.text()).toBe(expected);
    } else {
      expect(new Uint8Array(await response.arrayBuffer())).toEqual(expected);
    }
    if (body !== undefined) {
      expect(response.headers.get("content-type")).toBe("text/plain; charset=utf-8");
    }
  });
}
