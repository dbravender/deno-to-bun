# Bun migration

Use Bun 1.4.4. Install with `bun install --frozen-lockfile`, run the suite with
`bun run test`, and check types with `bun run typecheck` (or the preserved
`bun run check` entry point). The test script checks types before executing tests,
as the previous Deno test task did. TypeScript uses `strict: true` and checks
all source and test files without emitting JavaScript or skipping library checks.
No run, serve, or build task existed in the original project.

The assertion dependency remains `@std/assert` 1.0.19, installed through its JSR
npm distribution using an npm alias. `.npmrc` routes the JSR scope to its registry;
`bun.lock` records exact dependency resolutions. No Deno runtime or configuration
is needed. The count parser and all assertion expressions remain unchanged.

Deno test registrations now use `bun:test`. The two awaited Deno steps become
two synchronous tests grouped under the same parent suite; their original bodies
are synchronous, so completion semantics remain intact. Bun reports five passing
tests and one skip, where Deno reported four passing tests with two steps and one
ignored test. The async test is still awaited, object equality still uses the
same assertion library, and the expensive opt-in test stays skipped.

Bun does not provide Deno's permission sandbox or Deno test resource/operation
sanitizers. Tests now run with the process's normal filesystem, network, and
subprocess access; use operating-system isolation when running untrusted code.
Bun's direct `bun test` command transpiles without type checking; use `bun run test`
to preserve checking before tests.

Validation: the original Deno suite and strict check passed. After migration,
Bun's test suite, strict typecheck, preserved check script, and frozen-lockfile
install passed. A temporary invalid assignment was rejected by the typecheck
script and removed after verification. Formatting/lint replacement is out of scope.
