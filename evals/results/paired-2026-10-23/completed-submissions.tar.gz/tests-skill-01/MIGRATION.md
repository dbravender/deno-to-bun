# Bun migration

Use Bun 1.4.4 or newer. Install with `bun install --frozen-lockfile`, run tests with `bun run test`, and run strict whole-project checking with `bun run typecheck`. The existing `check` task is retained as an alias. This project had no run, serve, build, format, or lint tasks.

The runtime source and all assertion bodies are unchanged. `@std/assert` stays at 1.0.19, delivered through the official JSR npm compatibility registry. Bun generated `bun.lock`; Bun type declarations are pinned to 1.4.4. The baseline resolved `@std/internal` to 1.0.12; an override preserves that transitive version rather than accepting the newer registry resolution. Resolved versions are now frozen by Bun.

The test file now uses Bun's `.test.ts` discovery convention. Deno's four passing parent tests (including two nested steps) and one ignored test become five passing Bun cases and one skipped case: the nested parent becomes a named suite containing its two original steps. Async completion, deep structural equality, error assertions, and the intentional skip are preserved. Bun does not reproduce Deno test resource/operation leak sanitizers or its permission sandbox. These tests use neither filesystem/network operations nor permission options; run untrusted tests in an OS/container sandbox if needed. Implicit dotenv loading is disabled in `bunfig.toml` to preserve Deno's environment behavior.

Validation: Deno baseline tests and checking passed before migration. Bun strict checking and tests passed with Deno absent from PATH. A clean disposable copy installed using the frozen lockfile and passed both checks. No formatter/linter replacement or broad reformatting was performed. No deployment or hosted CI was run.
